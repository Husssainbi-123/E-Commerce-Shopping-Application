package com.shopping.exception;

public class AdminDataInvalidException extends RuntimeException{
	
	private String exceptionMessage;
	
	public AdminDataInvalidException()
	{
		
	}

	public AdminDataInvalidException(String exceptionMessage) {
		super();
		this.exceptionMessage = exceptionMessage;
	}

	public String getExceptionMessage() {
		return exceptionMessage;
	}

	public void setExceptionMessage(String exceptionMessage) {
		this.exceptionMessage = exceptionMessage;
	}

	@Override
	public String toString() {
		return "AdminDataInvalidException [exceptionMessage=" + exceptionMessage + "]";
	}
	
	

}
