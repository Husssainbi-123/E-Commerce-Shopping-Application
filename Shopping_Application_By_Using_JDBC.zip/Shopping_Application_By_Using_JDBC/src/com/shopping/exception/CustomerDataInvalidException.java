package com.shopping.exception;

public class CustomerDataInvalidException extends RuntimeException {
	
	private String exceptionmsg;
	
	public CustomerDataInvalidException() {}

	public CustomerDataInvalidException(String exceptionmsg) {
		super();
		this.exceptionmsg = exceptionmsg;
	}

	public String getExceptionmsg() {
		return exceptionmsg;
	}

	
	@Override
	public String toString()
	{
		return getClass() + " "+getExceptionmsg();
	}

}
