package com.shopping.service;

import java.util.List;

import com.shopping.dao.CartDAO;
import com.shopping.dto.Cart;
import com.shopping.dto.Product;

public class CartService {
	CartDAO cartDAO=new  CartDAO();
	
	public void addCartDetails(Cart cart)
	{
		if(cartDAO.insertCartDetails(cart))
		{
			System.out.println("Products Added To The Cart");
		}
		else
		{
			System.out.println("Server error 500");
		}
	}
	
	public List<Product> productDetails(int cid)
	{
		return cartDAO.listOfProductDetails(cid);
	}
}
