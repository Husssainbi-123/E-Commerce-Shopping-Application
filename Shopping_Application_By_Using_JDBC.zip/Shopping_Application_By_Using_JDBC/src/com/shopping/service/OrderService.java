package com.shopping.service;

import java.sql.Date;
import java.util.Scanner;

import com.shopping.dao.OrderDAO;
import com.shopping.dto.Order;
import com.shopping.dto.Payment;

public class OrderService {
	OrderDAO orderDAO=new OrderDAO();
	Scanner sc=new Scanner(System.in);
	
	public void storeOrderDetails(Payment payment,int quantity,String address)
	{
		Order order=new Order();
		order.setcID(payment.getcID());
		order.setpID(payment.getpID());
		order.setPquantity(quantity);
		order.setOrderDate(Date.valueOf(payment.getPayment_Date()));
		System.out.println("Select Address To Deliver the Product \n 1."+address+" \n 2.Change Address");
		switch (sc.nextInt()) {
		case 1:
			order.setOaddress(address);
			break;
		case 2:
			System.out.println("Enter New Address");
			String newAddress=sc.next();
			order.setOaddress(newAddress);
			break;
		default:
			System.out.println("Invalid Choice");
			break;
		}	
		if(orderDAO.insertOrderDetails(order))
		{
			System.out.println(order);
		}
		else
		{
			System.out.println("Server 500");
		}
		
	}
}
