package com.shopping.service;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.shopping.dao.CartDAO;
import com.shopping.dao.CustomerDAO;
import com.shopping.dao.ProductDAO;
import com.shopping.dto.Cart;
import com.shopping.dto.Customer;
import com.shopping.dto.Payment;
import com.shopping.dto.Product;
import com.shopping.exception.CustomerDataInvalidException;

public class CustomerService {
	CustomerDAO customerDAO=new CustomerDAO();
	ProductService productService=new ProductService();
	CartService cartService=new CartService();
	Customer customer;
	Scanner sc=new Scanner(System.in);
	public void customerRegistration()
	{
		List<Customer>listOfCustomer=customerDAO.selectAllCustomersDetails();
		System.out.println("Enter Customer Name");
		String cname=sc.next();
		System.out.println("Enter Customer EmailID");
		while(true)
		{
		String cemailID=sc.next();
		long emailIDCount=listOfCustomer.stream().filter((customers)->customers.getCemailID().equalsIgnoreCase(cemailID)).count();
		if(emailIDCount>0)
		{
			throw new CustomerDataInvalidException("EmailID Already Existed");
		}
		try {
		if(!(cemailID.contains("@gmail.com")))
		{
			throw new CustomerDataInvalidException("Invalid EmailID");
		}
		else
		{
			customer.setCemailID(cemailID);
			break;
		}
		}
		catch (CustomerDataInvalidException e) {
			System.out.println(e.getExceptionmsg());
			System.out.println("Re-enter customer emailID");
		}
		}
		System.out.println("Enter Customer Mobile Number");
		while(true)
		{
			long cmn=sc.nextLong();
			long cmnCount=listOfCustomer.stream().filter((customers)->customers.getCmn()==cmn).count();
			if(cmnCount>0)
			{
				throw new CustomerDataInvalidException("Mobile Number Already Existed");
			}
		try
		{
		if(!(cmn>=6000000000l && cmn<=9999999999l))
		{
			throw new CustomerDataInvalidException("Invalid Mobile Number");
		}
		else
		{
			customer.setCmn(cmn);
			break;
		}
		}
		catch (CustomerDataInvalidException e) {
			System.out.println(e.getExceptionmsg());
			System.out.println("Re-enter Mobile number");		
		}
		}
		System.out.println("Enter Customer Address");
		String caddress=sc.next();
		System.out.println("Enter Customer Gender");
		String cgender=sc.next();
		System.out.println("Enter Customer Password");
		String cpassword=sc.next();
		long passwordCount=listOfCustomer.stream().filter((customer)->customer.getPassword().equalsIgnoreCase(cpassword)).count();
		if(passwordCount>0)
		{
			throw new CustomerDataInvalidException("Password Already Existed");
		}
		customer.setCname(cname);
		customer.setCaddress(caddress);
		customer.setCgender(cgender);
		customer.setPassword(cpassword);
		boolean res= customerDAO.insertCustomerDetails(customer);
		if(res)
		{
			System.out.println(cname+ " Registration Successfully");
		}
		else
		{
			System.out.println("Server 500");
		}

	}
	public void customerLogin()
	{
		System.out.println("Enter EmailID Or Mobile Number");
		String emailIDOrMobileNumber=sc.next();
		System.out.println("Enter Password");
		String password=sc.next();
		customer= customerDAO.selectCustomerDetailsByUSingEmailIDOrMobileNumberAndPassword(emailIDOrMobileNumber,password);
		if(customer!=null)
		{
			System.out.println("Login Successfully...");
			if(customer.getCgender().equalsIgnoreCase("female"))
			{
				System.out.println("Hello Miss : "+customer.getCname());
				customerOperations();
			}
			if(customer.getCgender().equalsIgnoreCase("male"))
			{
				System.out.println("Hello Mr's : "+customer.getCname());
				customerOperations();
			}
		}
		else
		{
			System.out.println("Invalid EmailIDOrMobileNumber or Password");
		}
	}
	
	public void customerOperations()
	{
		System.out.println("Enter \n 1.For All Product Details \n 2.For Cart Details \n 3.For Order Details");
		switch(sc.nextInt())
		{
		case 1:
			List<Product> listOfProduct=productService.allProductDetails();
			int num=1;
			for (Product product : listOfProduct) {
				System.out.println("s.No : "+num++);
				System.out.println("Product Name : "+product.getPname());
				System.out.println("Product Brand : "+product.getPbrand());
				System.out.println("Product Price : "+product.getPprice());
				System.out.println("Product Category : "+product.getPcategory());
				System.out.println("Product MF Date : "+product.getPmfd());
				System.out.println("Product Ex Date : "+product.getPed());
				System.out.println("Product Discount : "+product.getPdiscount());
				System.out.println("---------------------------------------------");
			}
			System.out.println("select S.No to Add To Cart Or To Buy");
			int s_No=sc.nextInt();
			Product product = listOfProduct.get(s_No-1);
			System.out.println(product);
			System.out.println("select \n 1.To Add the Products to the cart \n 2.To Buy");
			switch (sc.nextInt()) {
			case 1:
				CartService cartService=new CartService();
				Cart cart=new Cart();
				System.out.println("Enter Product Quantity");
				int quantity=sc.nextInt();
				cart.setcID(customer.getcID());
				cart.setpID(product.getpID());
				cart.setCproductquantity(quantity);
				cartService.addCartDetails(cart);
				System.out.println("Add the details to the cart");
				break;
			case 2:
				System.out.println("Enter Product Quantity");
				quantity=sc.nextInt();
				System.out.println("Product Name : "+product.getPname());
				System.out.println("Product Brand : "+product.getPbrand());
				System.out.println("Product Price : "+product.getPprice() );
				System.out.println("Product Category : "+product.getPcategory());
				System.out.println("Total Price : "+product.getPprice()*quantity);
				System.out.println("Total Discount : "+(product.getPprice()*((product.getPdiscount()/100)))*quantity);
				double totalAmount=(product.getPprice()*quantity)-((product.getPprice()*(product.getPdiscount()/100))*quantity);
				System.out.println("Tota Amount Should pay : "+totalAmount);
				Payment payment=new Payment();
				PaymentService paymentService=new PaymentService();
				paymentService.paymentProcessDetails(product.getpID(),customer.getcID(),totalAmount,product.getPquantity(),customer.getCaddress());
				break;
			default:
				System.out.println("Invalid option");
				break;
			}
			break;
		case 2: 
			System.out.println("All Cart Details");
			productService.displayProductDetails(cartService.productDetails(customer.getcID()));
			break;
		case 3:
			System.out.println("All Order Details");
			break;
		default:
			System.out.println("Invalid Choice");
		}
	}
	
}
