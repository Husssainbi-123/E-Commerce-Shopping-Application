package com.shopping.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.shopping.dao.ProductDAO;
import com.shopping.dto.Product;

public class ProductService {
	
	Scanner sc=new Scanner(System.in);
	Product product=new Product();
	ProductDAO productDAO=new ProductDAO();
//	Product_ID, Product_Name, Product_Brand, Product_Price, Product_M_F_Date, Product_EX_Date, Product_Quantity, Product_Category, Product_Discount
	public void storageProductDetails()
	{
		System.out.println("Enter Product_Name ");
		String pName=sc.next();
		System.out.println("Enter Product_Brand ");
		String pBrand=sc.next();
		System.out.println("Enter Product_Price ");
		double pPrice=sc.nextDouble();
		System.out.println("Enter Product_M_F_Date ");
		String pMFDate=sc.next();
		System.out.println("Enter Product_EX_Date ");
		String pEXDate=sc.next();
		System.out.println("Enter Product_Quantity ");
		int pQuantity=sc.nextInt();
		System.out.println("Enter Product_Category ");
		String pCategory=sc.next();
		System.out.println("Enter Product_Discount ");
		double pDiscount=sc.nextDouble();
		product.setPname(pName);
		product.setPbrand(pBrand);
		product.setPprice(pPrice);
//		valueOf() return type Date
//		Date,arg String
		product.setPmfd(Date.valueOf(pMFDate));
		product.setPed(Date.valueOf(pEXDate));
		product.setPquantity(pQuantity);
		product.setPcategory(pCategory);
		product.setPdiscount(pDiscount);
		
		if(productDAO.insertProductDetails(product))
		{
			System.out.println("Products Stored Successfully");
		}
		else
		{
			System.out.println("Server 500");
		}
		
	}
	
	public void storageProductsByUsingBrand()
	{
		String arr[]= {"First","Second","Third","Fourth","Fifth"};
		List<Product>listOfProducts=new ArrayList<Product>();
		System.out.println("Enter Product_Brand ");
		String pBrand=sc.next();
		System.out.println("Number Of Products under "+pBrand+" Brand");
		int noOfProducts=sc.nextInt();
		for(int i=0;i<noOfProducts;i++)
		{
		System.out.println("Enter "+arr[i]+" Product Details");
		System.out.println("Enter Product_Name ");
		String pName=sc.next();
		System.out.println("Enter Product_Price ");
		double pPrice=sc.nextDouble();
		System.out.println("Enter Product_M_F_Date ");
		String pMFDate=sc.next();
		System.out.println("Enter Product_EX_Date ");
		String pEXDate=sc.next();
		System.out.println("Enter Product_Quantity ");
		int pQuantity=sc.nextInt();
		System.out.println("Enter Product_Category ");
		String pCategory=sc.next();
		System.out.println("Enter Product_Discount ");
		double pDiscount=sc.nextDouble();
		product.setPname(pName);
		product.setPbrand(pBrand);
		product.setPprice(pPrice);
		product.setPmfd(Date.valueOf(pMFDate));
		product.setPed(Date.valueOf(pEXDate));
		product.setPquantity(pQuantity);
		product.setPcategory(pCategory);
		product.setPdiscount(pDiscount);
		listOfProducts.add(product);
		}
		if(productDAO.insertMoreThanOneProduct(listOfProducts))
		{
			System.out.println("Product inserted Successfully");
		}
		else
		{
			System.out.println("Server error 500");
		}
	}
	
	public List<Product> allProductDetails()
	{
		return productDAO.listOfProductDetails();
	}
	
	public void displayProductDetails(List<Product> listOfProducts)
	{
		List<Product> productDetails=productDAO.listOfProductDetails();
		
		for(Product product: productDetails)
		{
			for(Product p : listOfProducts)
			{
				if(p.getpID()==product.getpID())
				{
					System.out.println(product);
					System.out.println("-----------------------------");
				}
			}
		}
	}

}
