package com.shopping.service;

import java.time.LocalDate;
import java.util.Scanner;

import com.shopping.dao.PaymentDAO;
import com.shopping.dto.Payment;
import com.shopping.dto.Product;

public class PaymentService {
	OrderService orderService=new OrderService();
	Scanner sc=new Scanner(System.in);
	public void paymentProcessDetails(int pid,int cid,double totalAmount,int quantity,String address)
	{
		Product product=new Product();
		Payment payment=new Payment();
		payment.setcID(cid);
		payment.setpID(pid);
		payment.setPayment_Date(LocalDate.now());
		System.out.println("Enter \n 1.For UPI \n 2.For Cash On Delivery \n 3.Debit \n 4.NetPayment \n 5.EMI");
		switch (sc.nextInt()) {
		case 1:
			payment.setpType("UPI");
			payment.setpStatus("Payment Success");
			break;
		case 2:
			payment.setpType("Cash On Delivery");
			payment.setpStatus("Under Proccessing");
			break;
		case 3:
			payment.setpType("Debit");
			payment.setpStatus("Payment Success");
			break;
		case 4:
			payment.setpType("NetPayment");
			payment.setpStatus("Payment Success");
			break;
		case 5:
			payment.setpType("EMI");
			payment.setpStatus("Under Proccessing");
			break;
		default:
			System.out.println("Invalid Choice");
			break;
		}
		System.out.println("Enter Amount : ");
		double amount=sc.nextDouble();
		
		if(amount==totalAmount)
		{
			payment.setPamount(amount);
			System.out.println(payment);
			PaymentDAO paymentDAO=new PaymentDAO();
			if(paymentDAO.insertPaymentDetails(payment))
			{
				System.out.println("Order Placed Successfully....");
				orderService.storeOrderDetails(payment,quantity,address);
				
			}
			else
			{
				System.out.println("Server error 500");
			}
			
		}	
	}
}
