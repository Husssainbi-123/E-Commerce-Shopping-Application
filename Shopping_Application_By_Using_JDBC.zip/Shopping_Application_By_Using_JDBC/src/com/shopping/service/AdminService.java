package com.shopping.service;

import java.util.List;
import java.util.Scanner;

import com.shopping.dao.AdminDAO;
import com.shopping.dto.Admin;
import com.shopping.exception.AdminDataInvalidException;

public class AdminService {
	
	Scanner sc=new Scanner(System.in);
	AdminDAO adminDAO=new AdminDAO();
	Admin admin=new Admin();
	ProductService productService=new ProductService();
	public void adminRegistration()
	{
		List<Admin> listOfAdminDetails=adminDAO.selectAdminDetails();
		System.out.println("Enter Admin EmailID");
		while(true)
		{
		String aEmail=sc.next();
		long emailIDCount=listOfAdminDetails.stream().filter((admins)->admins.getAemailID().equalsIgnoreCase(aEmail)).count();
		if(emailIDCount>0)
		{
			throw new AdminDataInvalidException("EmailID Already Existed");
		}
		else
		{
		try
		{
			if(!(aEmail.contains("@gmail.com")))
			{
				throw new AdminDataInvalidException("Invalid  EmailID");
			}
			else
			{
				admin.setAemailID(aEmail);
				break;
			}
		}
		catch (AdminDataInvalidException e) {
			System.out.println(e.getExceptionMessage());
			System.out.println("Re-enter Admin emailID");
		}
		}
		}
		System.out.println("Enter Admin Password");
		String aPassword=sc.next();
		long passwordCount=listOfAdminDetails.stream().filter((admins)->admins.getApassword().equalsIgnoreCase(aPassword)).count();
		if(passwordCount>0)
		{
			throw new AdminDataInvalidException("Password Already Existed");
		}
		else
		{
			admin.setApassword(aPassword);
		}
		System.out.println("Enter Admin Role");
		String aRole=sc.next();
		admin.setAdminrole(aRole);
		if(adminDAO.insertAdminOfDetails(admin))
		{
			System.out.println("Registration Successfully");
		}
		else
		{
			System.out.println("server 500");
		}	
	}
	
	public void adminLogin()
	{
		System.out.println("Enter EmailID");
		String aemail=sc.next();
		System.out.println("Enter Password");
		String aPassword=sc.next();
		admin=adminDAO.selectAdminDetailsByUSingEmailIDAndPassword(aemail, aPassword);
		if(admin!=null)
		{
			System.out.println("Enter \n 1.To insert Product Details \n 2.To Insert Product Based On Brand");
			switch(sc.nextInt())
			{
			case 1:
				System.out.println("Insert Product Details");
				productService.storageProductDetails();
				break;
			case 2:
				System.out.println("Insert Product Based On Brand");
				productService.storageProductsByUsingBrand();
				break;
			default:
				System.out.println("Invalid Request");
				break;
				
			}
		}
		else
		{
			System.out.println("Invalid EmailID or Password");
		}
	}

}
