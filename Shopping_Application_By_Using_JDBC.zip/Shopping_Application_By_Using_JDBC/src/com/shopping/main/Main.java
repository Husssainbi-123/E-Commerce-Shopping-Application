package com.shopping.main;

import java.util.Scanner;

import com.shopping.service.AdminService;
import com.shopping.service.CustomerService;

public class Main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		boolean start=true;
		CustomerService customerService=new CustomerService();
		AdminService adminService=new AdminService();
//		String s="***---***Welcome to A14_Shopping***---***";
//		for(int i=0;i<s.length();i++)
//		{
//			try {
//				Thread.sleep(300);
//				System.out.print(s.charAt(i));
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//		System.out.println("Enter \n 1.For Admin Login \n 2.For Customer Registration \n 3.For Customet Login");
		while(start)
		{
		System.out.println("Enter \n 1.For Admin Login \n 2.For Customer Registration \n 3.For Customer Login \n 4.Admin Registration");
		switch(sc.nextInt())
		{
		case 1:
		{
			adminService.adminLogin();			
		}
			break;
		case 2:
		{
			customerService.customerRegistration();
		}
			break;
		case 3:
		{
			customerService.customerLogin();
		}
			break;
		case 4:
		{
			adminService.adminRegistration();
		}
			break;
		default :
		{
			System.out.println("Invalid Request");
		}
			break;
		}
		System.out.println("Do you want to continue Enter \n Yes \n No");
		String str=sc.next();
		if(str.equalsIgnoreCase("No"))
		{
			start=false;
			System.out.println("Than you Visit Again.......");
		}

		
		}
	}

}
