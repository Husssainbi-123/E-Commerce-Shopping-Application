package com.shopping.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.shopping.dto.Admin;
import com.shopping.util.JDBCConnection;

public class AdminDAO {
	
	private static final String insert="insert into admin_details (Admin_EmailID, Admin_Password, Admin_Role) values (?,?,?)";
	private static final String select_Admin_Details="select * from admin_details";
	private static final String Admin_Login="Select * from admin_details where Admin_EmailID=? and Admin_Password=? ";
	Admin admin=new Admin();
	
	public boolean insertAdminOfDetails(Admin admin)
	{
		try {
			Connection connection=JDBCConnection.forMYSQLConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(insert);
			preparedStatement.setString(1, admin.getAemailID());
			preparedStatement.setString(2, admin.getApassword());
			preparedStatement.setString(3, admin.getAdminrole());
			int res=preparedStatement.executeUpdate();
			if(res>0)
			{
				return true;
			}
			else
			{
				return false;
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
		
	}
	
	public List<Admin> selectAdminDetails()
	{
		try {
			Connection connection=JDBCConnection.forMYSQLConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(select_Admin_Details);
			ResultSet resultSet=preparedStatement.executeQuery();
			List<Admin>listOfAdminDetails=new ArrayList<Admin>();
			if(resultSet.isBeforeFirst())
			{
			while(resultSet.next())
			{
				
				admin.setAemailID(resultSet.getString("Admin_EmailID"));
				admin.setAdminrole(resultSet.getString("Admin_Role"));
				admin.setApassword(resultSet.getString("Admin_Password"));
				listOfAdminDetails.add(admin);
			}
			
			return listOfAdminDetails;
			}
			return null;
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public Admin selectAdminDetailsByUSingEmailIDAndPassword(String emailID,String password)
	{
		try {
			Connection connection=JDBCConnection.forMYSQLConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(Admin_Login);
			preparedStatement.setString(1, emailID);
			preparedStatement.setString(2, password);
			ResultSet resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				admin.setAemailID(resultSet.getString("Admin_EmailID"));
				admin.setApassword(resultSet.getString("Admin_Password"));
				admin.setAdminrole(resultSet.getString("Admin_Role"));
			}
			return admin;
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
}
