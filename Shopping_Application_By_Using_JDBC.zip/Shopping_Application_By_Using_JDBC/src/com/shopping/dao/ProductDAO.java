package com.shopping.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.shopping.dto.Product;
import com.shopping.util.JDBCConnection;

public class ProductDAO {
	private static final String insert="insert into product_details (Product_Name, Product_Brand, Product_Price, Product_M_F_Date, Product_EX_Date, Product_Quantity, Product_Category, Product_Discount) values (?,?,?,?,?,?,?,?)";
	private static final String select_Product_Details="select * from product_details";
	public boolean insertProductDetails(Product product)
	{
		try {
			Connection connection=JDBCConnection.forMYSQLConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(insert);
			preparedStatement.setString(1, product.getPname());
			preparedStatement.setString(2, product.getPbrand());
			preparedStatement.setDouble(3, product.getPprice());
			preparedStatement.setDate(4, product.getPmfd());
			preparedStatement.setDate(5, product.getPed());
			preparedStatement.setInt(6, product.getPquantity());
			preparedStatement.setString(7, product.getPcategory());
			preparedStatement.setDouble(8, product.getPdiscount());
			int res=preparedStatement.executeUpdate();
			if(res>0)
			{
				return true;
			}
			else
			{
				return false;
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean insertMoreThanOneProduct(List<Product> listOfProducts)
	{
		try {
			Connection connection=JDBCConnection.forMYSQLConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(insert);
			for(Product product:listOfProducts)
			{
			preparedStatement.setString(1, product.getPname());
			preparedStatement.setString(2, product.getPbrand());
			preparedStatement.setDouble(3, product.getPprice());
			preparedStatement.setDate(4, product.getPmfd());
			preparedStatement.setDate(5, product.getPed());
			preparedStatement.setInt(6, product.getPquantity());
			preparedStatement.setString(7, product.getPcategory());
			preparedStatement.setDouble(8, product.getPdiscount());
			}
			preparedStatement.addBatch();
			int[]res=preparedStatement.executeBatch();
			if(res.length>0)
			{
				return true;
			}
			else
			{
				return false;
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	
	public List<Product> listOfProductDetails()
	{
//Product_Name, Product_Brand, Product_Price, Product_M_F_Date, Product_EX_Date, Product_Quantity, Product_Category, Product_Discount
		try {
			Connection connection=JDBCConnection.forMYSQLConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(select_Product_Details);
			ResultSet resultSet=preparedStatement.executeQuery();
			List<Product>listOfProducts=new ArrayList<Product>();
			while(resultSet.next())
			{
				Product product=new Product();
				product.setpID(resultSet.getInt("Product_ID"));
				product.setPname(resultSet.getString("Product_Name"));
				product.setPbrand(resultSet.getString("Product_Brand"));
				product.setPprice(resultSet.getDouble("Product_Price"));
				product.setPmfd(resultSet.getDate("Product_M_F_Date"));
				product.setPed(resultSet.getDate("Product_EX_Date"));
				product.setPquantity(resultSet.getInt("Product_Quantity"));
				product.setPcategory(resultSet.getString("Product_Category"));
				product.setPdiscount(resultSet.getDouble("Product_Discount"));
				listOfProducts.add(product);
				
			}
			return listOfProducts;
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
