package com.shopping.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.shopping.dto.Payment;
import com.shopping.util.JDBCConnection;

public class PaymentDAO {
	
	private static final String insert="insert into payment_details( Customer_ID, Product_ID, Payment_Type, Payment_Status, Amount, Payment_Date) values (?,?,?,?,?,?)";
	private static final String select_payment_datils="Select * from payment_details";
	public boolean insertPaymentDetails(Payment payment)
	{
		try {
			Connection connection=JDBCConnection.forMYSQLConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(insert);
			preparedStatement.setInt(1, payment.getcID());
			preparedStatement.setInt(2, payment.getpID());
			preparedStatement.setString(3, payment.getpType());
			preparedStatement.setString(4, payment.getpStatus());
			preparedStatement.setDouble(5, payment.getPamount());
			preparedStatement.setDate(6, Date.valueOf(payment.getPayment_Date()));
			int res=preparedStatement.executeUpdate();
			if(res>0)
			{
				return true;
			}
			return false;
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}

	public List<Payment> listOfPaymentDetails()
	{
		try {
			Connection connection=JDBCConnection.forMYSQLConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(select_payment_datils);
			ResultSet resultSet=preparedStatement.executeQuery();
			List<Payment>listOfPayments=new ArrayList<Payment>();
			if(resultSet.isBeforeFirst())
			{
				while(resultSet.next())
				{
					Payment payment=new Payment();
					payment.setPaymentID(resultSet.getInt("Payment_ID"));
					payment.setcID(resultSet.getInt("Customer_ID"));
					payment.setpID(resultSet.getInt("Product_ID"));
					payment.setpType(resultSet.getString("Payment_Type"));
					payment.setPamount(resultSet.getDouble("Amount"));
					payment.setpStatus(resultSet.getString("Payment_Status"));
//					payment.setPayment_Date(resultSet.getDate("Payment_Date"));
					listOfPayments.add(payment);
					
				}
				return listOfPayments;
			}
			return null;
			} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	}
}
