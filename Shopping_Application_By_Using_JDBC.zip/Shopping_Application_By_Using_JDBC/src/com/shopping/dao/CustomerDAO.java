package com.shopping.dao;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.shopping.dto.Customer;
import com.shopping.util.JDBCConnection;


public class CustomerDAO {
	
	private static final String insert="insert into customer_details(Customer_Name, Customer_EmailID, Customer_MobileNumber, Customer_Address, Customer_Gender, Customer_Password) values (?,?,?,?,?,?)"; 
	private static final String select_all_customer="select * from customer_details";
	private static final String cutomer_login="select * from customer_details where (Customer_EmailID=? or Customer_MobileNumber=?) and Customer_Password=?";
	public boolean insertCustomerDetails(Customer customer)
	{
		
		try {
			Connection connection=JDBCConnection.forMYSQLConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(insert);
		preparedStatement.setString(1,customer.getCname() );
		preparedStatement.setString(2, customer.getCemailID());
		preparedStatement.setLong(3, customer.getCmn());
		preparedStatement.setString(4, customer.getCaddress());
		preparedStatement.setString(5, customer.getCgender());
		preparedStatement.setString(6, customer.getPassword());
		int res=preparedStatement.executeUpdate();
		if(res!=0)
		{
			return true;
		}
		else
		{
			return false;
		}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
	}
	
	public List<Customer> selectAllCustomersDetails()
	{
//		select * from customer_details;
		try {
			Connection connection=JDBCConnection.forMYSQLConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(select_all_customer);
			ResultSet resultSet=preparedStatement.executeQuery();
			List<Customer>listOfCustomer=new ArrayList<Customer>();
			if(resultSet.isBeforeFirst())
			{
			while(resultSet.next())
			{
				Customer customer=new Customer();
				customer.setCemailID(resultSet.getString("Customer_EmailID"));
				customer.setCmn(resultSet.getLong("Customer_MobileNumber"));
				customer.setPassword(resultSet.getString("Customer_Password"));
				listOfCustomer.add(customer);
			}
			return listOfCustomer;
			}
			return null;
		}
		
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return null;	
	}
	
	public Customer selectCustomerDetailsByUSingEmailIDOrMobileNumberAndPassword(String emailIDOrMobileNumber,String password) {
		
		try {
			Connection connection=JDBCConnection.forMYSQLConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(cutomer_login);
			preparedStatement.setString(1, emailIDOrMobileNumber);
			preparedStatement.setString(2, emailIDOrMobileNumber);
			preparedStatement.setString(3, password);
			ResultSet resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				Customer customer=new Customer();
				customer.setcID(resultSet.getInt("Customer_ID"));
				customer.setCemailID(resultSet.getString("Customer_EmailID"));
				customer.setCmn(resultSet.getLong("Customer_MobileNumber"));
				customer.setPassword(resultSet.getString("Customer_Password"));
				customer.setCname(resultSet.getString("Customer_Name"));
				customer.setCgender(resultSet.getString("Customer_Gender"));
				customer.setCaddress(resultSet.getString("Customer_Address"));
				return customer;
				
			}
			else
			{
				return null;
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return  null;	
	}
}
