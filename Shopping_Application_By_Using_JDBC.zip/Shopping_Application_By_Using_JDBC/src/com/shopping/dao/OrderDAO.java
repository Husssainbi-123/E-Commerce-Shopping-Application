package com.shopping.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.shopping.dto.Order;
import com.shopping.util.JDBCConnection;

public class OrderDAO {
	
	private static final String insert="insert into order_details (Customer_ID, Product_ID, Product_Quantity, Order_Address, Order_Date) values (?,?,?,?,?)";
	
	public boolean insertOrderDetails(Order order) 
	{
		try {
			Connection connection=JDBCConnection.forMYSQLConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(insert);
			preparedStatement.setInt(1, order.getcID());
			preparedStatement.setInt(2, order.getpID());
			preparedStatement.setInt(3, order.getPquantity());
			preparedStatement.setString(4,order.getOaddress() );
			preparedStatement.setDate(5, order.getOrderDate());
			int res=preparedStatement.executeUpdate();
			if(res!=0)
			{
				return true;
			}
			return false;
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	
}
