package com.shopping.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.shopping.dto.Cart;
import com.shopping.dto.Product;
import com.shopping.util.JDBCConnection;

public class CartDAO {
	
	private static final String insert="insert into cart_details(Product_ID, Customer_ID, Product_Quantity) values(?,?,?)";
	private static final String select_Product_Details="select * from cart_details where Customer_ID=?";
	public boolean insertCartDetails(Cart cart)
	{
		try {
			Connection connection=JDBCConnection.forMYSQLConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(insert);
			preparedStatement.setInt(1, cart.getpID());
			preparedStatement.setInt(2, cart.getcID());
			preparedStatement.setInt(3, cart.getCproductquantity());
			int res=preparedStatement.executeUpdate();
			if (res>0) {
				return true;
			} else {
					return false;
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
	
	public List<Product> listOfProductDetails(int cID)
	{
		
		try {
			List<Product>listOfProduct=new ArrayList<Product>();
			Connection connection=JDBCConnection.forMYSQLConnection();
			PreparedStatement preparedStatement=connection.prepareStatement(select_Product_Details);
			preparedStatement.setInt(1, cID);
			ResultSet resultSet=preparedStatement.executeQuery();
			if(resultSet.isBeforeFirst())
			{
				while(resultSet.next())
				{
					Product product=new Product();
					product.setpID(resultSet.getInt("Product_ID"));
					listOfProduct.add(product);
				}
				
				return listOfProduct;
			}
			else
			{
				return null;
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
		
	}

}
