package com.shopping.dto;

import java.sql.Date;
import java.time.LocalDate;

public class Payment {
	

	private int paymentID;
	private int cID;
	private int pID;
	private String pType;
	private String pStatus;
	private double pamount;
	private LocalDate payment_Date;
	
	public Payment() {}

	public Payment(int cID, int pID, String pType, String pStatus, double pamount, LocalDate payment_Date) {
		super();
		this.cID = cID;
		this.pID = pID;
		this.pType = pType;
		this.pStatus = pStatus;
		this.pamount = pamount;
		this.payment_Date = payment_Date;
	}

	public void setPaymentID(int paymentID) {
		this.paymentID = paymentID;
	}

	public int getcID() {
		return cID;
	}

	public void setcID(int cID) {
		this.cID = cID;
	}

	public int getpID() {
		return pID;
	}

	public void setpID(int pID) {
		this.pID = pID;
	}

	public String getpType() {
		return pType;
	}

	public void setpType(String pType) {
		this.pType = pType;
	}

	public String getpStatus() {
		return pStatus;
	}

	public void setpStatus(String pStatus) {
		this.pStatus = pStatus;
	}

	public double getPamount() {
		return pamount;
	}

	public void setPamount(double pamount) {
		this.pamount = pamount;
	}
	public LocalDate getPayment_Date() {
		return payment_Date;
	}

	public void setPayment_Date(LocalDate payment_Date) {
		this.payment_Date = payment_Date;
	}

	public int getPaymentID() {
		return paymentID;
	}
	
//	Payment_ID, Customer_ID, Product_ID, Payment_Type, Payment_Status, Amount, payment_details, Payment_Date
	@Override
	public String toString()
	{
		return "Payment_ID : "+getPaymentID()+"\n"+"Customer_ID : "+getcID()+"\n"+"Product_ID : "+getpID()+"\n"+"Payment_Type : "+getpType()+"\n"+"Payment_Status : "+getpStatus()+"\n"+"Amount : "+getPamount()+"\n"+"Payment_Date : "+getPayment_Date();
	}
	
}
