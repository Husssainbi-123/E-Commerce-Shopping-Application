package com.shopping.dto;

import java.io.Serializable;

import com.shopping.dao.CustomerDAO;

public class Customer implements Serializable {
	private int cID;
	private String cname;
	private String cemailID;
	private long cmn;
	private String caddress;
	private String cgender;
	private String password;
	
	public Customer() {}

	public Customer(String cname, String cemailID, long cmn, String caddress, String cgender, String password) {
		this.cname = cname;
		this.cemailID = cemailID;
		this.cmn = cmn;
		this.caddress = caddress;
		this.cgender = cgender;
		this.password = password;
	}

	public String getCemailID() {
		return cemailID;
	}

	public void setCemailID(String cemailID) {
		this.cemailID = cemailID;
	}

	public int getcID() {
		return cID;
	}

	public void setcID(int cID) {
		this.cID = cID;
	}

	public long getCmn() {
		return cmn;
	}

	public void setCmn(long cmn) {
		this.cmn = cmn;
	}

	public String getCaddress() {
		return caddress;
	}

	public void setCaddress(String caddress) {
		this.caddress = caddress;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	public void  setCname(String cname) {
		this.cname=cname;
	}
	public String getCname() {
		return cname;
	}
	public void  setCgender(String cgender) {
		this.cgender=cgender;
	}
	public String getCgender() {
		return cgender;
	}
	
	// Customer_ID, Customer_Name, Customer_EmailID, Customer_MobileNumber, Customer_Address, Customer_Gender, Customer_Password
	@Override
	public String toString()
	{
		return "Customer Name : "+getCname()+"\n"+"Customer_EmailID : "+getCemailID()+"\n"+"Customer_MobileNumber : "+getCmn()+"\n"+"Customer_Address : "+getCaddress()+"\n"+"Customer_Gender : "+getCgender()+"\n"+"Customer_Password : "+getPassword();
	}

}
