package com.shopping.dto;

import java.io.Serializable;
import java.sql.Date;

public class Order implements Serializable {
	
	
	private int oID;
	private int cID;
	private int pID;
	private int pquantity;
	private String oaddress;
	private Date orderDate;
	
	public Order() {}

	public Order(int cID, int pID, int pquantity, String oaddress, Date orderDate) {
		this.cID = cID;
		this.pID = pID;
		this.pquantity = pquantity;
		this.oaddress = oaddress;
		this.orderDate = orderDate;
	}

	public int getcID() {
		return cID;
	}

	public int getpID() {
		return pID;
	}

	public int getPquantity() {
		return pquantity;
	}

	public void setPquantity(int pquantity) {
		this.pquantity = pquantity;
	}

	public String getOaddress() {
		return oaddress;
	}

	public void setOaddress(String oaddress) {
		this.oaddress = oaddress;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public int getoID() {
		return oID;
	}
//	Order_ID, Customer_ID, Product_ID, Product_Quantity, Order_Address, Order_Date
	@Override
	public String toString()
	{
		return "Order_ID : "+getoID()+"\n"+"Customer_ID : "+getcID()+"\n"+"Product_ID : "+getpID()+"\n"+"Product_Quantity : "+getPquantity()+"\n"+"Order_Address : "+getOaddress()+"\n"+"Order_Date : "+getOrderDate();
	}

	public void setoID(int oID) {
		this.oID = oID;
	}

	public void setcID(int cID) {
		this.cID = cID;
	}

	public void setpID(int pID) {
		this.pID = pID;
	}
	

}
