package com.shopping.dto;

import java.io.Serializable;
import java.sql.Date;

public class Product implements Serializable {
	
	private int pID;
	private String pname;
	private String pbrand;
	private double pprice;
	private Date pmfd;
	private Date ped;
	private int pquantity;
	private String pcategory;
	private double pdiscount;
	
	public Product() {}

	public Product(String pname, String pbrand, double pprice, Date pmfd, Date ped, int pquantity, String pcategory,
			double pdiscount) {
		this.pname = pname;
		this.pbrand = pbrand;
		this.pprice = pprice;
		this.pmfd = pmfd;
		this.ped = ped;
		this.pquantity = pquantity;
		this.pcategory = pcategory;
		this.pdiscount = pdiscount;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getPbrand() {
		return pbrand;
	}

	public void setPbrand(String pbrand) {
		this.pbrand = pbrand;
	}

	public double getPprice() {
		return pprice;
	}

	public void setPprice(double pprice) {
		this.pprice = pprice;
	}

	public Date getPmfd() {
		return pmfd;
	}

	public void setPmfd(Date pmfd) {
		this.pmfd = pmfd;
	}

	public Date getPed() {
		return ped;
	}

	public void setPed(Date ped) {
		this.ped = ped;
	}

	public int getPquantity() {
		return pquantity;
	}

	public int getpID() {
		return pID;
	}

	public void setpID(int pID) {
		this.pID = pID;
	}

	public void setPquantity(int pquantity) {
		this.pquantity = pquantity;
	}

	public String getPcategory() {
		return pcategory;
	}

	public void setPcategory(String pcategory) {
		this.pcategory = pcategory;
	}

	public double getPdiscount() {
		return pdiscount;
	}

	public void setPdiscount(double pdiscount) {
		this.pdiscount = pdiscount;
	}
//	Product_ID, Product_Name, Product_Brand, Product_Price, Product_M_F_Date, Product_EX_Date, Product_Quantity, Product_Category, Product_Discount
	@Override
	public String toString()
	{
		return "Product_Name : "+getPname()+"\n"+"Product_Brand : "+getPbrand()+"\n"+"Product_Price : "+getPprice()+"\n"+"Product_M_F_Date : "+getPmfd()+"\n"+"Product_EX_Date : "+getPed()+"\n"+"Product_Quantity : "+getPquantity()+"\n"+"Product_Category : "+getPcategory()+"\n"+"Product_Discount : "+getPdiscount();
		}
	
}
