package com.shopping.dto;

import java.io.Serializable;

public class Admin implements Serializable {
	
//	Admin_ID, Admin_EmailID, Admin_Password, Admin_Role
	private int aID;
	private String aemailID;
	private String apassword;
	private String adminrole;
	
	public Admin() {}

	public Admin(String aemailID, String apassword, String adminrole) {
		this.aemailID = aemailID;
		this.apassword = apassword;
		this.adminrole = adminrole;
	}

	public String getAemailID() {
		return aemailID;
	}

	public void setAemailID(String aemailID) {
		this.aemailID = aemailID;
	}

	public String getApassword() {
		return apassword;
	}

	public void setApassword(String apassword) {
		this.apassword = apassword;
	}

	public String getAdminrole() {
		return adminrole;
	}

	public void setAdminrole(String adminrole) {
		this.adminrole = adminrole;
	}
	
	@Override
	public String toString()
	{
		return "Admin_EmailID : "+getAemailID()+"\n"+"Admin_Password : "+getApassword()+"\n"+"Admin_Role : "+getAdminrole();
		}
	

}
