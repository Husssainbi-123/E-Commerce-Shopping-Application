package com.shopping.dto;

import java.io.Serializable;

public class Cart implements Serializable{
	
	
	private int cartID;
	private int pID;
	private int cID;
	private int cproductquantity;
	
	public Cart() {}

	public Cart(int pID, int cID, int cproductquantity) {
		this.pID = pID;
		this.cID = cID;
		this.cproductquantity = cproductquantity;
	}

	public int getCartID() {
		return cartID;
	}

	public void setCartID(int cartID) {
		this.cartID = cartID;
	}

	public int getpID() {
		return pID;
	}

	public void setpID(int pID) {
		this.pID = pID;
	}

	public int getcID() {
		return cID;
	}

	public void setcID(int cID) {
		this.cID = cID;
	}

	public int getCproductquantity() {
		return cproductquantity;
	}

	public void setCproductquantity(int cproductquantity) {
		this.cproductquantity = cproductquantity;
	}
//	Cart_ID, Product_ID, Customer_ID, Product_Quantity
	@Override
	public String toString()
	{
		return "Cart_ID : "+getCartID()+"\n"+"Product_ID : "+getpID()+"\n"+"Customer_ID : "+getcID()+"\n"+"Product_Quantity : "+getCproductquantity();
	}
}
